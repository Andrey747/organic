<?php
/*
Template Name: Team member
*/
	organics_storage_set('single_style', 'single-team');
    get_template_part('single');
?>