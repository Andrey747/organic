<?php
// Autoload layouts in this folder
$name = pathinfo(__FILE__);
organics_autoload_folder( 'templates/trx_testimonials' );
?>