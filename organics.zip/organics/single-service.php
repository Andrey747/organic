<?php
/*
Template Name: Service item
*/

get_template_part('single');
?>