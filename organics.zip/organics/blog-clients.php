<?php
/**
Template Name: Clients list
 */
organics_storage_set('blog_filters', 'clients');
get_template_part('blog');
?>