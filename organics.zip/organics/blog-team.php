<?php
/**
Template Name: Team members list
 */
organics_storage_set('blog_filters', 'team');

get_template_part('blog');
?>