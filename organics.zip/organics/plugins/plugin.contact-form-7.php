<?php
/* Contact Form 7 support functions
------------------------------------------------------------------------------- */

// Theme init priorities:
// 9 - register other filters (for installer, etc.)
if (!function_exists('organics_cf7_theme_setup')) {
    add_action( 'organics_action_before_init_theme', 'organics_cf7_theme_setup', 1 );
	function organics_cf7_theme_setup() {

		if (is_admin()) {
			add_filter( 'organics_filter_required_plugins',	'organics_cf7_required_plugins' );
		}
	}
}

// Filter to add in the required plugins list
if ( !function_exists( 'organics_cf7_required_plugins' ) ) {
	function organics_cf7_required_plugins($list=array()) {
        if (in_array('contact-form-7', (array)organics_storage_get('required_plugins'))){
			// CF7 plugin
			$list[] = array(
					'name' 		=> esc_html__('Contact Form 7', 'organics'),
					'slug' 		=> 'contact-form-7',
					'required' 	=> false
			);
		}
		return $list;
	}
}

// Check if cf7 installed and activated
if ( !function_exists( 'organics_exists_cf7' ) ) {
	function organics_exists_cf7() {
		return class_exists('WPCF7');
	}
}

?>