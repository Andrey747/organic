<?php
/* The GDPR Framework support functions
------------------------------------------------------------------------------- */

// Theme init
if (!function_exists('organics_product_delivery_date_theme_setup')) {
    add_action( 'organics_action_before_init_theme', 'organics_product_delivery_date_theme_setup', 1 );
    function organics_product_delivery_date_theme_setup() {
        if (is_admin()) {
            add_filter( 'organics_filter_required_plugins', 'organics_product_delivery_date_required_plugins' );
        }
    }
}

// Check if Instagram Widget installed and activated
if ( !function_exists( 'organics_exists_product_delivery_date' ) ) {
    function organics_exists_product_delivery_date() {
        return class_exists( 'Prdd_Lite_Woocommerce' );
    }
}

// Filter to add in the required plugins list
if ( !function_exists( 'organics_product_delivery_date_required_plugins' ) ) {
    function organics_product_delivery_date_required_plugins($list=array()) {
        if (in_array('product-delivery-date', (array)organics_storage_get('required_plugins')))
            $list[] = array(
                'name'         => esc_html__('Product Delivery Date for WooCommerce', 'organics'),
                'slug'         => 'product-delivery-date-for-woocommerce-lite',
                'required'     => false
            );
        return $list;
    }
}