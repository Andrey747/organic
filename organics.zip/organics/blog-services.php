<?php
/**
Template Name: Services list
 */
organics_storage_set('blog_filters', 'services');
get_template_part('blog');
?>